const ALLOWED_ORIGINS = new Set([
  'https://myohy12c.github.io',
  'https://jarvis-ai-alpha-rouge.vercel.app'
]);

function cors(req, res) {
  const origin = req.headers?.origin;
  if (origin && (ALLOWED_ORIGINS.has(origin) || /\.vercel\.app$/i.test(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  } else {
    res.setHeader('Access-Control-Allow-Origin', '*');
  }
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');
  res.setHeader('Access-Control-Max-Age', '600');
}

export default async function handler(req, res) {
  cors(req, res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST, OPTIONS');
    return res.status(405).json({ error: 'Method not allowed.' });
  }
  if (!process.env.GROQ_API_KEY) {
    return res.status(500).json({ error: 'GROQ_API_KEY is not configured in Vercel.' });
  }

  try {
    let body = req.body || {};
    if (typeof body === 'string') {
      try { body = JSON.parse(body); } catch { body = {}; }
    }

    const encoded = String(body.audio || '');
    if (!encoded) return res.status(400).json({ error: 'Missing audio.' });

    const cleanMime = String(body.mime || 'audio/webm').split(';')[0].toLowerCase();
    const ext = cleanMime.includes('wav') ? 'wav'
      : cleanMime.includes('mp4') || cleanMime.includes('m4a') ? 'mp4'
      : cleanMime.includes('mpeg') || cleanMime.includes('mp3') ? 'mp3'
      : cleanMime.includes('ogg') ? 'ogg'
      : 'webm';

    const bytes = Buffer.from(encoded, 'base64');
    if (!bytes.length) return res.status(400).json({ error: 'Empty audio.' });
    if (bytes.length > 5 * 1024 * 1024) {
      return res.status(413).json({ error: 'Voice clip is too large. Speak a shorter phrase.' });
    }

    const form = new FormData();
    form.append('file', new Blob([bytes], { type: cleanMime }), `jarvis.${ext}`);
    form.append('model', 'whisper-large-v3-turbo');
    form.append('response_format', 'json');
    form.append('language', 'en');
    form.append('temperature', '0');
    form.append(
      'prompt',
      'JARVIS voice assistant. Preserve commands, names, products, places, numbers, technical terms, YouTube, Google, Groq, Fish Audio, RTX, iPhone, Samsung, Vercel, GitHub.'
    );

    const upstream = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.GROQ_API_KEY}` },
      body: form,
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      return res.status(upstream.status).json({
        error: data?.error?.message || 'Groq transcription failed.',
      });
    }

    return res.status(200).json({
      text: String(data?.text || '').trim(),
    });
  } catch (error) {
    console.error('transcribe:', error);
    return res.status(500).json({
      error: error?.message || 'Transcription server error.',
    });
  }
}
