const ALLOWED_ORIGINS = new Set([
  'https://myohy12c.github.io',
  'https://jarvis-ai-alpha-rouge.vercel.app'
]);

const FISH_REFERENCE_ID = '372b91df180c465eb0bb6da69c4cd5f1';
const FISH_MODEL = 's2.1-pro-free';

function cors(req, res) {
  const origin = req.headers?.origin;
  if (origin && (ALLOWED_ORIGINS.has(origin) || /\.vercel\.app$/i.test(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  } else {
    res.setHeader('Access-Control-Allow-Origin', '*');
  }
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');
  res.setHeader('Access-Control-Max-Age', '600');
}

export default async function handler(req, res) {
  cors(req, res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST, OPTIONS');
    return res.status(405).json({ error: 'Method not allowed.' });
  }
  if (!process.env.FISH_API_KEY) {
    return res.status(500).json({ error: 'FISH_API_KEY is not configured in Vercel.' });
  }

  try {
    let body = req.body || {};
    if (typeof body === 'string') {
      try { body = JSON.parse(body); } catch { body = {}; }
    }
    const text = String(body.text || '').trim();
    if (!text) return res.status(400).json({ error: 'Missing text.' });

    const upstream = await fetch('https://api.fish.audio/v1/tts', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.FISH_API_KEY}`,
        'Content-Type': 'application/json',
        'model': FISH_MODEL,
      },
      body: JSON.stringify({
        text: text.slice(0, 8000),
        reference_id: FISH_REFERENCE_ID,
        format: 'mp3',
      }),
    });

    if (!upstream.ok) {
      const detail = (await upstream.text()).slice(0, 1600);
      return res.status(upstream.status).json({
        error: detail || 'Fish Audio request failed.',
      });
    }

    const buffer = Buffer.from(await upstream.arrayBuffer());
    res.statusCode = 200;
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'audio/mpeg');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Content-Length', String(buffer.length));
    res.end(buffer);
  } catch (error) {
    console.error('tts:', error);
    if (!res.headersSent) return res.status(500).json({
      error: error?.message || 'TTS server error.',
    });
    res.end();
  }
}
