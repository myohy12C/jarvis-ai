const ALLOWED_ORIGINS = new Set([
  'https://myohy12c.github.io',
  'https://jarvis-ai-alpha-rouge.vercel.app'
]);
export default async function handler(req, res) {
  const origin = req.headers?.origin;
  res.setHeader('Access-Control-Allow-Origin',
    origin && (ALLOWED_ORIGINS.has(origin) || /\.vercel\.app$/i.test(origin)) ? origin : '*');
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');
  res.setHeader('Access-Control-Max-Age', '600');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'GET') return res.status(405).json({error:'Method not allowed.'});
  return res.status(200).json({
    ok:true,
    message:'JARVIS services are online.',
    ai:Boolean(process.env.GROQ_API_KEY),
    fish:Boolean(process.env.FISH_API_KEY),
    timestamp:new Date().toISOString()
  });
}
