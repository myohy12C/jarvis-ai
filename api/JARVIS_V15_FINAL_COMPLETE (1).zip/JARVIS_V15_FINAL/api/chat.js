const ALLOWED_ORIGINS = new Set([
  'https://myohy12c.github.io',
  'https://jarvis-ai-alpha-rouge.vercel.app'
]);

function cors(req, res) {
  const origin = req.headers?.origin;
  if (origin && (ALLOWED_ORIGINS.has(origin) || /\.vercel\.app$/i.test(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin);
  } else {
    res.setHeader('Access-Control-Allow-Origin', '*');
  }
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');
  res.setHeader('Access-Control-Max-Age', '600');
}

export default async function handler(req, res) {
  cors(req, res);
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST, OPTIONS');
    return res.status(405).json({ error: 'Method not allowed.' });
  }
  if (!process.env.GROQ_API_KEY) {
    return res.status(500).json({ error: 'GROQ_API_KEY is not configured in Vercel.' });
  }

  try {
    let body = req.body || {};
    if (typeof body === 'string') {
      try { body = JSON.parse(body); } catch { body = {}; }
    }
    const messages = Array.isArray(body.messages) ? body.messages : [];
    if (!messages.length) {
      return res.status(400).json({ error: 'messages must be a non-empty array.' });
    }

    const cleanMessages = messages.slice(-20).map((m) => ({
      role: m?.role === 'assistant' ? 'assistant' : m?.role === 'system' ? 'system' : 'user',
      content: String(m?.content ?? '').slice(0, 12000)
    }));

    const upstream = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'openai/gpt-oss-20b',
        messages: cleanMessages,
        temperature: 0.2,
        max_completion_tokens: 900,
        reasoning_effort: cleanMessages.some((m) => /\b(debug|code|analy[sz]e|compare|calculate|research|explain in detail)\b/i.test(String(m.content || '')) || String(m.content || '').length > 900) ? 'medium' : 'low',
        reasoning_format: 'hidden',
        stream: true,
      }),
    });

    if (!upstream.ok) {
      const detail = (await upstream.text()).slice(0, 1600);
      return res.status(upstream.status).json({
        error: detail || 'Groq request failed.',
      });
    }

    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');

    const reader = upstream.body?.getReader();
    if (!reader) return res.end();

    const decoder = new TextDecoder();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        res.write(decoder.decode(value, { stream: true }));
      }
    } finally {
      try { reader.releaseLock(); } catch {}
    }
    res.end();
  } catch (error) {
    console.error('chat:', error);
    if (!res.headersSent) return res.status(500).json({
      error: error?.message || 'Server error.',
    });
    res.end();
  }
}
