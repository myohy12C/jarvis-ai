# JARVIS V15 FINAL

## Deployment
Upload the complete project, preserving the `api/` folder, to the GitHub repository connected to Vercel. Use the Vercel deployment as the primary app URL.

Required Vercel environment variables:
- `GROQ_API_KEY`
- `FISH_API_KEY`

The Fish voice is fixed in code to reference ID `372b91df180c465eb0bb6da69c4cd5f1` with `s2.1-pro-free`. No voice selector is required.

The microphone uses browser microphone capture and falls back to the Groq Whisper Turbo transcription endpoint. The frontend uses the Vercel project endpoint automatically.

Orb controls: short click toggles the microphone; dragging or holding manipulates the view; wheel zooms 1x-6x. Listening/processing do not reshape the orb; only Fish speech expands it.
