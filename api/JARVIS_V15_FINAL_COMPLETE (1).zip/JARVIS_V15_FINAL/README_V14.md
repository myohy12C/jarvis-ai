# JARVIS V14

This is the clean baseline build.

## Voice
- Persistent getUserMedia microphone stream.
- Fast browser SpeechRecognition is used when available.
- Persistent VAD + MediaRecorder falls back to Groq Whisper Turbo.
- A one-shot browser SpeechRecognition fallback is used when the transcription API cannot be reached.
- Fish Audio output is locked in code to reference ID `372b91df180c465eb0bb6da69c4cd5f1` using `s2.1-pro-free`.

## AI
- Groq streaming chat uses `openai/gpt-oss-20b`.
- The UI starts rendering deltas immediately.
- The response prompt/context is kept compact for latency.

## Orb
- Fully transparent canvas with no rectangular compositor glow.
- Free-look drag with inertia.
- Smooth 1x-4x zoom.
- Higher rendering detail at higher zoom levels.
- Internal cinematic code glyphs and energy filaments.

## UI
- Soft rounded controls and glass-like surfaces inspired by Apple's current Liquid Glass interaction guidance.
- Old service-worker cache is invalidated by cache versioning.

## Deployment
Use the Vercel deployment as the primary site so the API is same-origin. Required Vercel environment variables:
- GROQ_API_KEY
- FISH_API_KEY
